# LRU-Cache
Designed a LRU cache by implementing the concepts of variousData Structuressuch asQueue &amp; Hash maps,where Queue is implemented using adoubly-linked listand Hash acts as address of the corresponding Queue node
